package assignment1; /* Student Name: Tristan Becnel, Lab Section: 17400 */

import java.util.Scanner;
public class Problem2 {

    public static void main(String[] args) {
     //   System.out.println("Hello, World!");
        siphon();
    }
    public static void siphon() {
        System.out.println("Insert paragraph of string");
        Scanner scnr = new Scanner(System.in); //Reads user input
        String s = scnr.nextLine();
        scnr.close();
        char[] arrayS = s.toCharArray();

        int counter = 0;
        double pos = 0;
        int startIndex = 0;
        //    String s = scnr.next();    //changes scnr.nextLine() to scnr.next() in order to only decipher a word at a time
            for (int i = 0; i < arrayS.length; i++) {
                if (Character.isLetter(arrayS[i])|| (!Character.isWhitespace(arrayS[i]))) {
                        if (!Character.isLetter(arrayS[i])) {
                            counter++;
                            continue;
                        }
                char ch = Character.toLowerCase(s.charAt(i));
                pos += ch - 'a' + 1;
                counter++;
            }
         else {
                      if (pos == 100) {                  //
                          System.out.println(s.substring(startIndex, counter));
                      }
                      counter++;
                      startIndex = counter;
                      pos = 0;
            }
        }
        if (pos == 100) {                  //
            System.out.println(s.substring(startIndex, counter));
        }
    }
}
