package assignment1; /* Student Name: Tristan Becnel, Lab Section: 17400 */

import java.util.Scanner;

public class Problem1 {
    public static void main(String[] args) {
       // System.out.println("Hello, World!");
        int large = largestProduct();
        System.out.println(large);
    }

    public static int largestProduct() {
        Scanner scnr = new Scanner(System.in); //Reads user input
        System.out.println("Print number of adjacent digits");
        int n = scnr.nextInt();      // Reads number of adjacent digits
        scnr.nextLine();
        System.out.println("Print string of digits to be searched through");
        String s = scnr.nextLine();  // Reads a 1000-digit number to search through
      //  scnr.nextLine();
        scnr.close();

        int[] n1 = new int[s.length()];
        for(int i = 0; i < s.length(); i++) {     //convert the string into an int array. changed n to i (error).
            n1[i] = Integer.parseInt(String.valueOf(s.charAt(i))); //changed n1[n] to n1[i]. error on me
        }

        int sumProduct = -9999;
        //   int x = s.length(counter + y);
        //changed n1.length-n to n1.length. Might have to worry about out of bound errors with program looking past n
        for (int i = 0; i < (n1.length); i++) { // s.length() - n to avoid errors with searching outside the array n1
            int sum = 1;
            int safe = n;
            int counter = 0;

            while (safe > 0 && (counter+i) < n1.length) {
              //  if ((n1[counter + i] * sum) > sumProduct) { //removed y from s.length(counter + y). Removed if statement because it preemptively compares to sumproduct before finishing
                    sum = n1[counter + i] * sum;
                    if (sum > sumProduct) {
                        sumProduct = sum;
                    }
            //    }
                safe--;
                counter++;
            }
        }
        return sumProduct;
    }
}