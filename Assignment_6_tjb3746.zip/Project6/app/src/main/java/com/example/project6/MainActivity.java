package com.example.project6;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.example.apilibrary.Models.Request.MeasurementUnit;
import com.example.apilibrary.Models.Request.RequestApi;
import com.example.apilibrary.Models.Response.Current;
import com.example.apilibrary.Models.Response.Daily;
import com.example.apilibrary.Models.Response.ResponseApi;
import com.example.apilibrary.WeatherResponse;
import com.example.apilibrary.ApiClient;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ApiClient apiClient = new ApiClient("26b4bb1adde46c9773ac5755e94f4ea4");
        RequestApi oneCallApiRequest = new RequestApi.buildApi(30.267153, -97.743057)
                .unit(MeasurementUnit.imperial)
                .buildApi();

        apiClient.makeOneCallApiRequest(oneCallApiRequest, new WeatherResponse() {
            @Override
            public void onSuccessfulResponse(ResponseApi response) {
                Log.e("Current Temperature", ""+ response.getCurrent().getTemp());
                Log.e("Current Humidity", ""+ response.getCurrent().getHumidity());
                Log.e("Current Pressure", ""+ response.getCurrent().getPressure());
                Log.e("Current Wind Speed", ""+ response.getCurrent().getWindSpeed());

                Current[] hourlyTemp = response.getHourly();
                Daily[] dailyTemp = response.getDaily();
                TextView poop = (TextView)findViewById(R.id.poop);
                poop.setText("Current Temperature: "+ response.getCurrent().getTemp() +"\n"
                + "Current Humidity: " + response.getCurrent().getHumidity() + "\n"
                + "Current Pressure: " + response.getCurrent().getPressure() + "\n"
                + "Current Wind Speed: " + response.getCurrent().getWindSpeed() + "\n\n"
                + "Hourly Temperature Present: " + hourlyTemp[0].getTemp() + "\n"
                + "Hourly Temperature in 1 hour: " + hourlyTemp[1].getTemp() + "\n"
                + "Hourly Temperature in 2 hours: " + hourlyTemp[2].getTemp() + "\n"
                + "Hourly Temperature in 3 hours: " + hourlyTemp[3].getTemp() + "\n"
                + "Hourly Temperature in 4 hours: " + hourlyTemp[4].getTemp() + "\n"
                + "Hourly Temperature in 5 hours: " + hourlyTemp[5].getTemp() + "\n\n"
                + "Daily Temperature Today: " + dailyTemp[0].getTemp().getDay() + "\n"
                + "Daily Temperature one day after today: " + dailyTemp[1].getTemp().getDay() +"\n"
                + "Daily Temperature two days after today: " + dailyTemp[2].getTemp().getDay() +"\n"
                + "Daily Temperature three days after today: " + dailyTemp[3].getTemp().getDay() + "\n"
                + "Daily Temperature four days after today: " + dailyTemp[4].getTemp().getDay() + "\n"
                + "Daily Temperature five days after today: " + dailyTemp[5].getTemp().getDay());




                //     System.out.println(hourlyTemp[0].getTemp());
                Log.e("Hourly Temperature Present", "" + hourlyTemp[0].getTemp());
                Log.e("Hourly Temperature in 1 hour", "" + hourlyTemp[1].getTemp()); //an array of type Current[]
                Log.e("Hourly Temperature in 2 hours", "" + hourlyTemp[2].getTemp()); //an array of type Current[]
                Log.e("Hourly Temperature in 3 hours", "" + hourlyTemp[3].getTemp()); //an array of type Current[]
                Log.e("Hourly Temperature in 4 hours", "" + hourlyTemp[4].getTemp()); //an array of type Current[]
                Log.e("Hourly Temperature in 5 hours", "" + hourlyTemp[5].getTemp()); //an array of type Current[]
                // System.out.println(response.getCurrent().getTemp());


                // Temp joe = dailyTemp[0].getTemp();
                //   System.out.println(dailyTemp[0].getTemp().getDay());
                Log.e("Daily Temperature Today", "" + dailyTemp[0].getTemp().getDay()); //
                Log.e("Daily Temperature one days after today", "" + dailyTemp[1].getTemp().getDay());
                Log.e("Daily Temperature two days after today", "" + dailyTemp[2].getTemp().getDay());
                Log.e("Daily Temperature three days after today", "" + dailyTemp[3].getTemp().getDay());
                Log.e("Daily Temperature four days after today", "" + dailyTemp[4].getTemp().getDay());
                Log.e("Daily Temperature five days after today", "" + dailyTemp[5].getTemp().getDay());
            }

            @Override
            public void onFailedResponse(Throwable t) {
                Log.e("Nyoooooo", t.getMessage());
            }
        });

    }
}