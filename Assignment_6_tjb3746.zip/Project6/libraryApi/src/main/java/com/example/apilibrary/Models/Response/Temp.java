package com.example.apilibrary.Models.Response;

public class Temp {
    private double day;

    public double getDay() {
        return day;
    }

    public void setDay(double value) {
        this.day = value;
    }

}