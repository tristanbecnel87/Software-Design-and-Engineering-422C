package com.example.apilibrary.Models.Response;

public class ResponseApi {
    private Current current;
    private Current[] hourly;
    private Daily[] daily;

    public Current getCurrent() {
        return current;
    }

    public void setCurrent(Current value) {
        this.current = value;
    }

    public Current[] getHourly() {
        return hourly;
    }

    public void setHourly(Current[] value) {
        this.hourly = value;
    }

    public Daily[] getDaily() {
        return daily;
    }

    public void setDaily(Daily[] value) {
        this.daily = value;
    }

}
