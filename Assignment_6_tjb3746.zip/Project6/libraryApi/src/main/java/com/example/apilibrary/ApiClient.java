package com.example.apilibrary;

import com.example.apilibrary.Models.Request.RequestApi;
import com.example.apilibrary.Models.Response.ResponseApi;
import com.example.apilibrary.Utilities.ApiService;
import com.example.apilibrary.Utilities.BuildApiService;


import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ApiClient {

    private String apiKey;

    public ApiClient(String apiKey) {
        this.apiKey = apiKey;
    }

    public void makeOneCallApiRequest(RequestApi request, WeatherResponse callback) {
        ApiService apiService = BuildApiService.getOneCallApiService();

        apiService.getWeather(request.getLatitude(), request.getLongitude(),  request.getMeasurementUnits().name(),  apiKey).enqueue(new Callback<ResponseApi>() {
            @Override
            public void onResponse(Call<ResponseApi> call, Response<ResponseApi> response) {
                if(response.isSuccessful()){
                    callback.onSuccessfulResponse(response.body());
                    return;
                }
                callback.onFailedResponse(new Throwable(response.message()));
            }

            @Override
            public void onFailure(Call<ResponseApi> call, Throwable t) {
                callback.onFailedResponse(t);
            }
        });    }

}
