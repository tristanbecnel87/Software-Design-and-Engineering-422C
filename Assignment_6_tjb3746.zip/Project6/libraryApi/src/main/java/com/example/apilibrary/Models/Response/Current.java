package com.example.apilibrary.Models.Response;

public class Current {
    private double temp;
    private double pressure;
    private double humidity;
    private double wind_speed;

    public double getTemp() {
        return temp;
    }

    public void setTemp(double value) {
        this.temp = value;
    }


    public double getPressure() {
        return pressure;
    }

    public void setPressure(long value) {
        this.pressure = value;
    }

    public double getHumidity() {
        return humidity;
    }

    public void setHumidity(long value) {
        this.humidity = value;
    }


    public double getWindSpeed() {
        return wind_speed;
    }

    public void setWindSpeed(double value) {
        this.wind_speed = value;
    }

}
