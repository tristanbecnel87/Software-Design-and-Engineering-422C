package com.example.apilibrary;

import com.example.apilibrary.Models.Response.ResponseApi;

public interface WeatherResponse {

    void onSuccessfulResponse(ResponseApi response);

    void onFailedResponse(Throwable t);
}
