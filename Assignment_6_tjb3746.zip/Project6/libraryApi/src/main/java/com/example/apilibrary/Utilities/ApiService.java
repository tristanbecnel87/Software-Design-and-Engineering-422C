package com.example.apilibrary.Utilities;


import com.example.apilibrary.Models.Response.ResponseApi;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiService {
    @GET("data/2.5/onecall")
    Call<ResponseApi> getWeather(@Query("lat") double lat, @Query("lon") double lon, @Query("units") String units,  @Query("appid") String appKey);
}
