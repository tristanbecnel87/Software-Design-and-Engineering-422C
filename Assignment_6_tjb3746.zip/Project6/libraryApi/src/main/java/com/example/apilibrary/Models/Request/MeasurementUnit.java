package com.example.apilibrary.Models.Request;

public enum MeasurementUnit {
    standard,
    metric,
    imperial
}
