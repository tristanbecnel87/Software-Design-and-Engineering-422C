package com.example.apilibrary.Models.Request;

public class RequestApi {
    private double latitude;
    private double longitude;
    private MeasurementUnit units;

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public MeasurementUnit getMeasurementUnits() {
        return units;
    }


    public static class buildApi{

        private double latitude;
        private double longitude;
        private MeasurementUnit units = MeasurementUnit.metric;

        public buildApi(double latitude, double longitude){
            this.latitude = latitude;
            this.longitude = longitude;
        }

        public buildApi unit(MeasurementUnit units){
            this.units = units;

            return this;
        }


        public RequestApi buildApi(){
            RequestApi apiRequest = new RequestApi();
            apiRequest.latitude = this.latitude;
            apiRequest.longitude = this.longitude;
            apiRequest.units = this.units;

            return apiRequest;
        }
    }
}
