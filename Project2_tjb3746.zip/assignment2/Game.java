/* EE422C Assignment #2 submission by
 * Replace <...> with your actual data.
 * <Tristan Becnel>
 * <tjb3746>
 */
package assignment2;

import java.util.Scanner;

public class Game extends GameConfiguration {
    private int practice;
    private boolean testingMode;
    private int value;
    private String code;
    private Scanner scnr = new Scanner(System.in);
    private int numberOfGuesses = guessNumber;

    private String history = "";

    Game start = null;

    public Game() {    //default constructor
        value = 0;
        testingMode = false;
        code = "AAAA"; //fake starter code
    }

    public Game(int value, boolean testingMode) { //constructor with boolean parameter
        if (value == 1) {
            this.testingMode = true;
        }
        code = SecretCodeGenerator.getInstance().getNewSecretCode();


    }

    public boolean getTestingMode() {
        return testingMode;
    }

    public String getCode() {
        return code;
    }

    public void startGame() {
        //  scnr = new Scanner(System.in);
        Welcome.WelcomeMsg();
        yesOrNo();
    }
    public void startGame1() {
        //  scnr = new Scanner(System.in);
        Welcome.WelcomeMsg();
        yesAgain(1);
    }

    public void yesOrNo() {
        char yesOrNo = scnr.next().charAt(0);
        if (yesOrNo == 'Y') {
            start = new Game(practice, false);  //create new game object proceed with game
        } else if (yesOrNo != 'Y') {
            System.exit(0); //ends program
        }
        System.out.print("\nGenerating secret code ...\n");
        if (start.getTestingMode() == true) {
            System.out.print(" (for this example the secret code is " + start.getCode() + ")\n");
        }
        start.runGame();
    }

    public void yesAgain(int value) {
        char yesOrNo = scnr.next().charAt(0);
     //   practice = value;
        if (yesOrNo == 'Y') {
            start = new Game(1, true);
            //create new game object proceed with game
        } else if (yesOrNo != 'Y') {
            System.exit(0); //ends program
        }
        System.out.print("\nGenerating secret code ...");
        if (start.getTestingMode() == true) {
            System.out.print(" (for this example the secret code is " + start.getCode() + ")\n");
        }
        start.runGame();
    }



    public void runGame() {
        if (numberOfGuesses > 0) {
            System.out.print("\nYou have " + numberOfGuesses + " guesses left. \n");
            guess();
            analyzeGuess();
        } else if (numberOfGuesses == 0) {
            System.out.print("Sorry, you are out of guesses. You lose, boo-hoo.");
            // System.exit(0);
        }
    }

    public void analyzeGuess() {
        //   scnr = new Scanner(System.in);
        String guess = scnr.nextLine();
        String answer = code; //error in code somewhere idk

        if (guess.equals("\n")) {
            System.out.print("\n"+ guess + " -> INVALID GUESS\n\n");
            guess();
            analyzeGuess();
        }

        if (guess.equals("HISTORY")) {
            System.out.print(history + "\n");
            System.out.print("\nYou have " + numberOfGuesses + " guesses left. \n");
            guess();
            analyzeGuess();
        }


        int whitePegs = 0;
        int blackPegs = 0;

        if (guess.length() > pegNumber) {
            System.out.print("\n"+ guess + " -> INVALID GUESS\n\n");
            guess();
            analyzeGuess();
        }
        char[] n1 = new char[guess.length()];
        char[] n2 = new char[guess.length()];
        String s = "";
        for (String n:colors)
            s+= n;
        char[] color = s.toCharArray();

        for (int i = 0; i < guess.length(); i++) {
            n1[i] = guess.charAt(i);
            n2[i] = answer.charAt(i);
        }
        int count = 0;
        for (int i = 0; i < guess.length(); i++) {
            if (Character.isLowerCase(n1[i])) {
                System.out.print("\n"+ guess + " -> INVALID GUESS\n\n");
                guess();
                analyzeGuess();
            }
        }
        for (int i = 0; i < n1.length;i++) {
            for (int j = 0; j < color.length;j++) {
                if (n1[i] == color[j]) {
                    count++;
                }
            }
        }
        if (count != pegNumber) {
            System.out.print("\n"+ guess + " -> INVALID GUESS\n\n");
            guess();
            analyzeGuess();
        }

        for (int i = 0; i < guess.length(); i++) {
            if (n1[i] == n2[i]) {           //correct location and color          //need to tinker more with for loop to make sure no double counting
                blackPegs++;                          //or anything occurs.
                n2[i] = 0; //remove entry for later
                n1[i] = 1; //remove entry
            }
        }
        for (int i = 0; i < guess.length(); i++) {
            for (int j = 0; j < guess.length(); j++) {
                // if (n1[j] == n2[j]) {                     //need to tinker more with for loop to make sure no double counting
                //     break;           //skip location because they're counted for in blackpegs              //or anything occurs.
                // }
                if (n2[j] == n1[i]) {
                    whitePegs++;
                    n2[j] = 0; //remove entry to avoid double counting
                    break;

                }
            }
        }

        if (blackPegs == pegNumber) {
            System.out.print("\n" + guess + " -> Result: " + blackPegs + "B_" + whitePegs + "W");
            System.out.print(" - You win !!");
            System.out.print("\n\nAre you ready for another game (Y/N):");
            if (testingMode == true) {
                yesAgain(1);
            }
            yesOrNo();
        }
        if (numberOfGuesses == 1 && blackPegs != pegNumber) {
            System.out.print("\nSorry, you are out of guesses. You lose, boo-hoo.");
            System.out.print("\n\nAre you ready for another game (Y/N):");
            if (testingMode == true) {
                yesAgain(1);
            }
            yesOrNo();
        }

        System.out.print("\n" + guess + " -> Result: " + blackPegs + "B_" + whitePegs + "W\n");
        String addToHistory = ("\n" + guess + "\t\t" + blackPegs + "B_" + whitePegs + "W");
        history = history + addToHistory;
        numberOfGuesses--;
        runGame();
    }
    public void guess() {
        System.out.print("What is your next guess? \n" +
                "Type in the characters for your guess and press enter.");
        System.out.print("\nEnter guess:");
    }
}