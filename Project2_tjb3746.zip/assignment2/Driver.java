/* EE422C Assignment #2 submission by
 * Replace <...> with your actual data.
 * <Tristan Becnel>
 * <tjb3746>
 */
package assignment2;

import java.util.Scanner;

public class Driver extends Game {

    public static void main (String[] args) {

        int commandValue = 0;
        if ( args.length > 0) {
            String s ="";
            for (String n:args)
                s+= n;
            char[] c1 = s.toCharArray();
            if (c1[0] ==49)
                commandValue = Integer.parseInt(args[0]);
            if (commandValue == 1) {
                Game a2 = new Game(1, true);
                a2.startGame1();
            }
        }
        else if (commandValue != 1)  {
            Game a2 = new Game();
            a2.startGame();
        }
        Game a2 = new Game();
        a2.startGame();

    }


}
