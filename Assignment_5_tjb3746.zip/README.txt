To use implementation, run MyServer.java, and then MyClient.java. To write a message to another
client output your message in the format of "message:client x" where x represents the client's
number. Numbering begins from 0, so the first client class you create, that client will be 0 so
to write a message to client 0 you can write "hello:client 0" and then client 0 will see
the message.