import java.io.*;
import java.util.*;
import java.net.*;
import java.util.ArrayList;


public class MyServer {
    static ArrayList<ThreadManager> list = new ArrayList<>(); //list of clients

    static int clientCount = 0;

    public static void main(String[] args) throws IOException {

        ServerSocket ss = new ServerSocket(7777); //accept clients if their port is 7777

        Socket socket;

        while (true) { //infinite loop to always keep looking for chatters/clients

            socket = ss.accept(); //accept client
            System.out.println("New client has been found!");

            DataInputStream din = new DataInputStream(socket.getInputStream());
            DataOutputStream dout = new DataOutputStream(socket.getOutputStream());

            ThreadManager client = new ThreadManager(socket,"client " + clientCount, din, dout); //names client by the order they were added to the list

            Thread thread = new Thread(client); //new thread

            System.out.println("Adding this client to active client list.\n");
            list.add(client); //add client to list

            thread.start(); //begin thread

            clientCount++;

        }
    }
}

class ThreadManager implements Runnable {
    Socket socket;
    boolean keepChat;
    private String name;
    final DataInputStream din;
    final DataOutputStream dout;

    public ThreadManager(Socket socket, String name, DataInputStream din, DataOutputStream dout) {
        this.socket = socket;
        this.keepChat=true;
        this.name = name;
        this.din = din;
        this.dout = dout;

    }

    @Override
    public void run() {
        while (true) {

            try {

                String message = din.readUTF();

                if(message.equals("quit")){
                    break; //end while loop and proceed to end socket
                }


                String[] parts = message.split(":"); // break the string into two parts, message and clientname
                String sendMessage = parts[0];
                String clientName = parts[1];

                for (ThreadManager mc : MyServer.list) {

                    if (this.keepChat==true && mc.name.equals(clientName))
                    {
                        mc.dout.writeUTF(this.name+": " + sendMessage);
                        break; //if Found then break
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        try {

            this.keepChat=false;
            this.socket.close();
            this.dout.flush();   //Close everything and shutdown thread
            din.reset();
            this.din.close();
            this.dout.close();


        }catch(IOException e){
            e.printStackTrace();
        }

    }
}