import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicBoolean;


public class MyClient {

public static void main(String[] args) throws IOException {
    Scanner scnr = new Scanner(System.in);             //establish scanner to read messages
    AtomicBoolean exit = new AtomicBoolean(true);

        Socket socket = new Socket("localhost", 7777); //establish connection

        DataInputStream din = new DataInputStream(socket.getInputStream());
        DataOutputStream dout = new DataOutputStream(socket.getOutputStream());


    Thread writeChat = new Thread(() -> {      //write chat to client
        while (true) {
            try {
                String message = scnr.nextLine();
                if(message.equals("quit")){
                    //this.isloggedin=false;
                    //this.socket.close();
                    exit.set(false);
                  //  System.exit(0); //it actu
                   // din.close();
                   // dout.close();
                   // break;
                }
                dout.writeUTF(message);             //message sent to server
                dout.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    });


    Thread readChat = new Thread(() -> {      //read chat from client
        while (exit.get() == true) { //checks to see if exit boolean is true or false. if true keep going, if false terminate while loop
            try {
                Thread.sleep(1000); //wait for other thread to catch up just in case user wants to logout
                String message = din.readUTF();
                if(message.equals("quit")){
                    //this.isloggedin=false;
                    //this.socket.close();
                    break;
                }
                System.out.println(message);       //print message from another client to the chat box
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
        }
    });
        writeChat.start();
        readChat.start();
    }
}